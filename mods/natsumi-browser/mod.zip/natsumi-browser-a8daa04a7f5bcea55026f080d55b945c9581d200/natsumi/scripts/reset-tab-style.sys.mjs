/*

Natsumi Browser - Welcome to your personal internet.

Copyright (c) 2024-present Green (@greeeen-dev)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

import * as ucApi from "chrome://userchromejs/content/uc_api.sys.mjs";

export function resetTabStyleIfNeeded() {
    let isProton = false;
    if (ucApi.Prefs.get("floorp.design.configs").exists()) {
        let floorpDesignConfig = JSON.parse(ucApi.Prefs.get("floorp.design.configs").value);
        isProton = floorpDesignConfig["globalConfigs"]["userInterface"] === "proton";

        // Check if other tab styles can be used
        let usesClassicTabs = false;
        let usesCustomTabs = false;
        if (ucApi.Prefs.get("natsumi.tabs.use-custom-type").exists()) {
            usesCustomTabs = ucApi.Prefs.get("natsumi.tabs.use-custom-type").value;
        }
        if (ucApi.Prefs.get("natsumi.tabs.type").exists()) {
            usesClassicTabs = ucApi.Prefs.get("natsumi.tabs.type").value === "classic";
        }

        // If the Classic tab design is in use, we can safely ignore the check
        if (usesClassicTabs && usesCustomTabs) {
            return false;
        }

        if (!isProton) {
            floorpDesignConfig["globalConfigs"]["userInterface"] = "proton";
            ucApi.Prefs.set("floorp.design.configs", JSON.stringify(floorpDesignConfig));
        }
    }

    return !isProton;
}